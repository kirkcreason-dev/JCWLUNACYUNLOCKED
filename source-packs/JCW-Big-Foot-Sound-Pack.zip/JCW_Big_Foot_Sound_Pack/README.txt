JCW LUNACY - BIG FOOT: SMALL WRESTLING SOUND PACK

12 original procedurally synthesized creature/game sound effects.
48,000 Hz / 16-bit PCM WAV / mono. No music or crowd ambience.
The preview plays files 01-12 in order, separated by 0.42 seconds.

FILES AND GAME TRIGGERS

01_BigFoot_Idle_Growl.wav (1.20s)
  Low throaty creature growl.
  Trigger: Idle or warning animation

02_BigFoot_Taunt_Roar.wav (1.80s)
  Longer rough roar, also suitable for victory.
  Trigger: Taunt or victory

03_BigFoot_Attack_Grunt_A.wav (0.36s)
  Short forceful attack grunt.
  Trigger: Punch, kick, or weapon swing

04_BigFoot_Attack_Grunt_B.wav (0.46s)
  Deeper alternate attack grunt.
  Trigger: Alternate attack; randomize with A

05_BigFoot_Hurt_Oof_A.wav (0.43s)
  Short creature pain reaction.
  Trigger: Light or medium damage

06_BigFoot_Hurt_Oof_B.wav (0.70s)
  Longer falling pain grunt.
  Trigger: Heavy damage or being thrown

07_BigFoot_Heavy_Footstep_A.wav (0.36s)
  Heavy bare-foot ring step.
  Trigger: Foot contact; alternate with B

08_BigFoot_Heavy_Footstep_B.wav (0.39s)
  Second heavy ring step.
  Trigger: Next foot contact; alternate with A

09_BigFoot_Heavy_Hit.wav (0.37s)
  Compact bassy body hit.
  Trigger: Strike contact; pair with a grunt

10_BigFoot_Ring_Body_Slam.wav (0.95s)
  Heavy body landing on canvas and wooden ring deck.
  Trigger: Body contacts ring

11_BigFoot_Chokeslam_Lift.wav (0.85s)
  Rising effort growl for the one-handed lift; no impact.
  Trigger: Special frames 2-3; stop naturally before impact

12_BigFoot_Chokeslam_Impact.wav (1.20s)
  Extra-heavy ring slam; no lift growl or windup.
  Trigger: Special frame 5: landing/contact

CHOKESLAM SYNC
Play 11 at the grip/lift transition (frames 2-3).
Play 12 exactly at the slam contact in frame 5.
These are separate sounds: the impact has no baked-in rev, roar, or windup.
Let the impact tail continue while frame 6 recovers.

IMPLEMENTATION
All clips are one-shots. Avoid looping the roar or impact tail.
Alternate footstep and grunt variants to reduce repetition.
Start at a conservative in-game volume; layered voices and impacts add together.
All WAV files have short edge fades and peaks below 0 dBFS.
Creature vocals are synthesized, not recordings of a performer or animal.
